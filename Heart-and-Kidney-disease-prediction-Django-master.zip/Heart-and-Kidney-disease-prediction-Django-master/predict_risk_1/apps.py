from django.apps import AppConfig


class PredictRisk1Config(AppConfig):
    name = 'predict_risk_1'
